import { Component, ViewChild } from '@angular/core';
import { Chart } from 'chart.js';
 
 
import {
  ChartComponent,
  ApexAxisChartSeries,
  ApexChart,
  ApexXAxis,
  ApexDataLabels,
  ApexStroke,
  ApexYAxis,
  ApexFill,
  ApexLegend,
  ApexPlotOptions
} from "ng-apexcharts";

export type ChartOptions = {
  series: any;
  chart: any;
  dataLabels: any;
  plotOptions: any;
  stroke: any;
  xaxis: any;
  yaxis: any;
  colors: any;
  fill: any;
  legend: any;
  title: any;
};
@Component({
  selector: 'app-test2',
  templateUrl: './test2.component.html',
  styleUrls: ['./test2.component.scss']
})
export class Test2Component {
  @ViewChild("chart") chart!: ChartComponent;
  public chartOptions: Partial<ChartOptions>;

  constructor() {
    this.chartOptions = {
      series: [
        {
          name: "Pending",
          data: [44, 55, 57, 56, 61,  ]
        },
        {
          name: "Completed",
          data: [76, 85, 101, 98, 87,  ]
        },
        
      ],
      chart: {
        type: "bar",
        height: 350
      },
      title: {
        text: "Stutent's Attentance",
        align: "left"
      },
      plotOptions: {
        bar: {
          horizontal: false,
          columnWidth: "55%",
          endingShape: "rounded"
        }
      },
      dataLabels: {
        enabled: false
      },
      stroke: {
        show: true,
        width: 2,
        colors: ["transparent"]
      },
      xaxis: {
        categories: [
          "Assignment",
          "Quiz",
          "Presentation",
          "Lab",
          "viva",
        
        ]
      },
      yaxis: {
        title: {
          //text: "$ (thousands)"
        },
        labels: {
          formatter: function(value:any) {
          
           
            return value +  ' %'
          }
        }
      },
      fill: {
        opacity: 1
      },
      colors: ['#91b07c', '#e7e7e7'], 
    };
  }
}
