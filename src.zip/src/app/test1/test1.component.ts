import { Component } from '@angular/core';

@Component({
  selector: 'app-test1',
  templateUrl: './test1.component.html',
  styleUrls: ['./test1.component.scss']
})
export class Test1Component {

  data:any =[{name:"Course Code",value:"Ba3102",type:"1"},
    {name:"Course Name",value:"Quantitative techniques" ,type:"1"},
    {name:"Course Type",value:"Program Elective",type:"1"},
    {name:"Course Period", type:"3" , value:[{name:"Semester" ,count:"1"}]},
    {name:"Credits",type:"3" , value:[{name:"lecture" ,count:"3"},{name:"Tutorial" ,count:"0"},{name:"Practical" ,count:"1"},{name:"Project" ,count:"0"}]},
    {name:"Course Outcomes (COs)",type:"4" , value:[{name:"CO2" },{name:"CO4" },{name:"CO5" },{name:"CO7" },{name:"CO13" },{name:"C14" }]},
    {name:"Mapped to this Cours",type:"4",value:[{name:"PO7" },{name:"PO8" },{name:"PO10" },{name:"PO12" }]},
    
  
  
  
  ]

}
